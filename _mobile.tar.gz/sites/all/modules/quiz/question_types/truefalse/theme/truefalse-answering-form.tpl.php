<?php

/**
 * @file
 * Handles the layout of the truefalse answering form.
 *
 * Variables available:
 * - $form.
 */
print drupal_render($form);
