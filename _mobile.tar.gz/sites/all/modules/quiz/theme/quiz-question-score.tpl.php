<div class="quiz-report-score-container <?php print $class ?>">
  <span>
    <?php print t('Score:') ?> <?php print $score ?> <?php print t('of') . ' ' . $max_score ?>
  </span>
</div>
